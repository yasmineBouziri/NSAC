// Add a widget file here to ship it. Each file only calls defineWidget().
import './time.js';
import './calendar.js';
import './space.js';
import './earth.js';
import './health.js';
import './games.js';
import './tools.js';
