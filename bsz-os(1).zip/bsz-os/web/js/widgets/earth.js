import { h } from '../core/util.js';
import { defineWidget } from '../core/registry.js';
import { feed } from '../core/data.js';
import { chart } from '../core/chart.js';
import { CITIES, S } from '../core/state.js';
import { count } from '../core/fx.js';

const COND = [['Clear', '☀'], ['Partly cloudy', '⛅'], ['Cloudy', '☁'], ['Rain', '☂'], ['Windy', '≋']];
function wxSim(city) {
  const [tz, , , avg] = CITIES[city] || CITIES.UTC;
  const hr = +new Intl.DateTimeFormat('en-GB', { timeZone: tz, hour: 'numeric', hourCycle: 'h23' }).format();
  let s = 0; for (const ch of city) s += ch.charCodeAt(0);
  const r = (s * 31 + Math.floor(Date.now() / 864e5) * 17) % 100;
  const hourly = Array.from({ length: 12 }, (_, i) => +(avg + 6 * Math.sin(((hr + i - 9) / 24) * 2 * Math.PI) + (r % 5) - 2).toFixed(1));
  return { temp: hourly[0], hourly, hum: 40 + (r % 45), wind: 6 + (r % 22), cond: COND[r % 5][0] };
}
defineWidget({
  id: 'weather', title: 'Weather on Earth', icon: '☂', group: 'Earth', size: 'm', desc: 'Conditions in any city back home', cfg: [{ key: 'city', label: 'City', type: 'city' }],
  mount(b, c) {
    const city = c.cfg.city || S.data.settings.city;
    const num = h('span'), t = h('div', { class: 'bigtime' }, num, h('small', {}, '°C')), cond = h('div', { class: 'sub' }), kv = h('div', { class: 'sub dim' }), cv = h('canvas', { class: 'cv' });
    b.append(t, cond, kv, cv);
    const ch = chart(cv, { color: '#38d9ff' });
    const un = feed('earth.weather?city=' + encodeURIComponent(city), () => wxSim(city), 30000)((d, sim) => {
      c.sim(sim);
      count(num, d.temp, 1);
      cond.textContent = `${(COND.find(x => x[0] === d.cond) || [])[1] || ''} ${d.cond}  ${city}`;
      kv.textContent = `Humidity ${d.hum}%   Wind ${d.wind} km/h   Next 12 h`;
      ch.set(d.hourly); ch.reveal();
    });
    return () => { un(); ch.destroy(); };
  },
});
