import './core/ai.js';
import './widgets/index.js';
import './core/pages.js';
import { h, $, every, pad } from './core/util.js';
import { api } from './core/api.js';
import { S, loadState, save, flush, CITIES } from './core/state.js';
import { pages } from './core/registry.js';
import { fx, sky, startStars } from './core/fx.js';
import { applyTheme } from './core/theme.js';
import { authScreen } from './core/auth.js';
import { startNotifications } from './core/notify.js';

const root = $('#root');
startStars($('#stars'));

async function boot() {
  const el = $('#boot');
  const eng = await api('engines').catch(() => []);
  const logo = h('div', { class: 'logo' }, [...'BSZ-OS'].map(c => h('span', {}, c)));
  const lines = [h('div', {}, 'display engine 0.1.0 ... ', h('b', {}, 'OK')),
    ...eng.map(e => h('div', {}, `${e.name} ${e.version || ''} ... `, h('b', { class: e.status === 'ok' ? '' : 'f' }, e.status === 'ok' ? (e.stub ? 'STUB' : 'OK') : 'FAIL')))];
  el.append(logo, h('div', { class: 'tag' }, 'Blood, Sweat and Zero-G'), h('div', { class: 'log' }, lines));
  const skip = new Promise(r => el.addEventListener('click', r, { once: true }));
  if (!fx.reduced && window.anime) {
    window.anime.animate(logo.children, { opacity: [0, 1], translateY: [24, 0], scale: [0.6, 1], delay: window.anime.stagger(70), duration: 600, ease: 'outBack' });
    window.Motion.animate(lines, { opacity: [0, 1], x: [-14, 0] }, { delay: window.Motion.stagger(0.12, { startDelay: 0.5 }), duration: 0.3 });
    await Promise.race([skip, new Promise(r => setTimeout(r, 900 + lines.length * 120))]);
    await window.Motion.animate(el, { opacity: 0 }, { duration: 0.35 });
  }
  el.remove();
}

let cur = null, view, title, pill, nav;
function shell() {
  const ids = [...pages.keys()];
  nav = h('nav', {}, pill = h('i', { class: 'pill', style: 'top:0px' }), ids.filter(i => !['engines', 'settings'].includes(i)).map(navBtn));
  const clock = h('span', { class: 'clock' }), dot = h('span', { class: 'dot' });
  const out = h('button', { class: 'ico', title: 'Sign out', onClick: async () => { await flush(); await api('auth/logout', { method: 'POST' }); location.reload(); } }, '⏻');
  title = h('h1');
  view = h('div', { class: 'view' });
  root.replaceChildren(h('div', { class: 'shell' },
    h('aside', { class: 'dock' }, h('div', { class: 'mark' }, 'BSZ'), nav, h('div', { class: 'sp' }), navBtn('engines'), navBtn('settings')),
    h('div', { class: 'col' }, h('header', { class: 'top' }, title, h('span', { class: 'chip' }, dot, h('span', { id: 'eng' }, 'engines')), clock, h('span', { class: 'chip' }, S.user.name, out)), view)));
  every(() => {
    const tz = CITIES[S.data.settings.city]?.[0] || 'UTC';
    clock.textContent = new Intl.DateTimeFormat('en-GB', { timeZone: tz, hour: '2-digit', minute: '2-digit', hourCycle: S.data.settings.h24 ? 'h23' : 'h12' }).format() + '  ' + S.data.settings.city;
  }, 15000);
  api('engines').then(l => { const bad = l.filter(e => e.status !== 'ok').length; $('#eng').textContent = `${l.length - bad}/${l.length} engines`; if (bad) dot.className = 'dot f'; else if (l.some(e => e.stub)) dot.className = 'dot s'; });
  addEventListener('hashchange', () => go(location.hash.slice(2)));
  go(location.hash.slice(2) || 'home', true);
  startNotifications();
}
function navBtn(id) { const p = pages.get(id); return h('button', { 'data-id': id, title: p.title, onClick: () => (location.hash = '#/' + id) }, p.icon); }

async function go(id, first) {
  const p = pages.get(id) || pages.get('home');
  if (!first && cur?.id === p.id) return;
  if (!first) { sky.warp(); if (!fx.reduced) await window.Motion.animate(view, { opacity: 0, y: -8 }, { duration: 0.14 }); }
  cur?.cleanup && cur.cleanup();
  title.textContent = p.title;
  document.querySelectorAll('.dock button').forEach(b => b.classList.toggle('on', b.dataset.id === p.id));
  const b = document.querySelector(`.dock nav button[data-id="${p.id}"]`);
  pill.style.opacity = b ? 1 : 0;
  if (b) fx.reduced ? (pill.style.top = b.offsetTop + 2 + 'px') : window.Motion.animate(pill, { top: b.offsetTop + 2 + 'px' }, { type: 'spring', stiffness: 380, damping: 28 });
  view.replaceChildren();
  cur = { id: p.id, cleanup: p.render(view) };
  if (!fx.reduced) window.Motion.animate(view, { opacity: [0, 1], y: [14, 0] }, { duration: 0.3 });
  const r = S.data.recent;
  if (r[0]?.id !== p.id) { r.unshift({ id: p.id, t: Date.now() }); r.length = Math.min(r.length, 20); save(); }
  window.dispatchEvent(new CustomEvent('bsz:nav', { detail: p.id }));
}

(async () => {
  applyTheme();
  await boot();
  try { S.user = await api('auth/me'); await loadState(); applyTheme(); shell(); }
  catch { authScreen(root, () => { applyTheme(); shell(); }); }
})();
