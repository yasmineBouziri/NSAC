import { S } from './state.js';
import { fx, sky } from './fx.js';
export function applyTheme() {
  const s = S.data.settings;
  document.documentElement.style.setProperty('--accent', s.accent);
  document.body.dataset.density = s.density;
  fx.reduced = s.motion === 'reduced' || matchMedia('(prefers-reduced-motion: reduce)').matches;
  sky.on = !!s.stars;
}
export const ACCENTS = { Blood: '#ff3b5c', Sweat: '#38d9ff', 'Zero-G': '#8b7bff', Solar: '#ffb02e', Life: '#3ddc97' };
