import { h, uid } from './util.js';
import { api } from './api.js';
import { S, save, CITIES, DEF } from './state.js';
import { definePage, defineApplet, widgets, pages } from './registry.js';
import { mountGrid } from './dashboard.js';
import { applyTheme, ACCENTS } from './theme.js';
import { pop } from './fx.js';

const fixed = (ids, size) => ids.map(id => ({ uid: uid(), type: id, size: size?.[id] || widgets.get(id)?.size || 'm', cfg: {} }));
const SIMNOTE = 'Preview with simulated data. Connect the matching engine to make these widgets live.';

// ---- Applets. Boilerplate: each one embeds reusable parts (old widgets) via parts(). Replace the body with the final design later. ----
const parts = (ids, size, note) => v => mountGrid(v, fixed(ids, size), false, note);
const A = (id, title, icon, group, desc, render) => defineApplet({ id, title, icon, group, desc, render });

A('home', 'Home', '◈', 'System', 'Applet launcher', v => {
  const list = [...pages.values()].filter(p => p.id !== 'home');
  const groups = [...new Set(list.map(p => p.group))];
  v.replaceChildren(h('div', { class: 'launcher' }, groups.map(g => h('section', {}, h('h3', {}, g),
    h('div', { class: 'apps' }, list.filter(p => p.group === g).map(p => h('button', { class: 'app', onClick: () => (location.hash = '#/' + p.id) }, h('i', {}, p.icon), h('b', {}, p.title), h('small', {}, p.desc))))))));
  pop(v.querySelectorAll('.app'));
});
A('physical', 'Physical health', '✚', 'Health', 'Vitals, domains, immune, recommendations', parts(['hscore', 'immune', 'domains', 'vitals', 'recs', 'hgraph', 'sleep'], { vitals: 'l' }, SIMNOTE + ' TODO: anatomical body view with per-organ bubbles (heart, bone, eyes...).'));
A('mental', 'Mental health', '☯', 'Health', 'Check-ins, surveys, tips, breathing, reaction test', parts(['checkin', 'mood', 'breath', 'pvt'], null, 'TODO: periodic surveys (PHQ-9, GAD-7, KSS, TLX), tips, trend.'));
A('sensors', 'Sensor monitor', '☢', 'Space', 'Radiation, solar, cabin air', parts(['radiation', 'solar', 'atmo', 'weather'], { solar: 'l' }, SIMNOTE));
A('clock', 'Clock', '◷', 'Tools', 'World time, mission elapsed time, calendar', parts(['citytime', 'met', 'calendar', 'binary']));
A('assistant', 'Assistant', '✦', 'Tools', 'Local AI chat', parts(['chat'], { chat: 'x' }));
A('tools', 'Tools', '⚒', 'Tools', 'Notes, hydration, recent', parts(['notes', 'water', 'recent']));
A('games', 'Games', '◉', 'Fun', 'Snake, 2048 (more planned)', parts(['snake', 'g2048']));
A('tutorial', 'Tutorial and about', '?', 'System', 'How BSZ-OS works', v => v.replaceChildren(h('div', { class: 'doc' }, h('h2', {}, 'About BSZ-OS'),
  h('p', {}, 'Offline first crew health environment. Engines (accounts, health, sensors, AI) are independent plugins. Applets are the user facing apps.'),
  h('p', {}, 'Data marked SIM is simulated. BSZ-OS is a decision support prototype, not a medical device. Alerts and thresholds never depend on the AI.'),
  h('p', {}, 'TODO: guided tutorial, hazards and risks explainer (see docs/SOURCES in the context hub).'))));
A('credits', 'Credits', '★', 'System', 'Team and sources', v => v.replaceChildren(h('div', { class: 'doc' }, h('h2', {}, 'Credits'),
  h('p', {}, 'Team: Blood, Sweat and Zero-G (INSAT, Tunisia). TODO: members and credentials.'),
  h('p', {}, 'Libraries: Motion, anime.js. Data and references: see the register in the context hub.'),
  h('p', {}, 'AI tools were used for code generation and drafting. No NASA branding is used in this app.'))));

const ROADMAP = [['health', 'Health engine'], ['statistics', 'Statistics engine'], ['knowledge', 'Knowledge base'], ['ai', 'Local AI engine'], ['sensors', 'Sensor acquisition']];
definePage({
  id: 'engines', title: 'Engines', icon: '⚙', group: 'System', desc: 'Engine status', render(v) {
    const box = h('div', { class: 'eng' });
    v.replaceChildren(box);
    api('engines').then(list => {
      const have = new Set(list.map(e => e.name));
      box.append(...list.map(e => h('div', { class: 'row' }, h('span', { class: 'dot ' + (e.status === 'ok' ? (e.stub ? 's' : '') : 'f') }),
        h('b', {}, e.name), h('span', { class: 'dim' }, e.error || (e.stub ? 'stub ' : '') + 'v' + e.version + '  ' + e.provides.join(', ')))),
        ...ROADMAP.filter(r => !have.has(r[0])).map(r => h('div', { class: 'row off' }, h('span', { class: 'dot f' }), h('b', {}, r[1]), h('span', { class: 'dim' }, 'not installed'))));
      pop(box.children);
    });
  },
});

definePage({
  id: 'settings', title: 'Settings', icon: '☰', group: 'System', desc: 'Theme, motion, clock, city', render(v) {
    const s = S.data.settings;
    const set = (k, val) => { s[k] = val; applyTheme(); save(); };
    const sel = (opts, cur, fn) => { const e = h('select', {}, opts.map(([val, l]) => h('option', { value: val, selected: String(val) === String(cur) }, l))); e.onchange = () => fn(e.value); return e; };
    const sw = h('div', { class: 'swatches' });
    const paint = () => sw.replaceChildren(...Object.entries(ACCENTS).map(([n, c]) => h('button', { class: 'sw' + (s.accent === c ? ' on' : ''), title: n, style: `background:${c}`, onClick: () => { set('accent', c); paint(); } })),
      Object.assign(h('input', { type: 'color', value: s.accent, title: 'Custom', style: 'width:44px;padding:2px' }), { oninput: e => set('accent', e.target.value), onchange: paint }));
    paint();
    const reset = h('button', { class: 'btn', onClick: () => { if (confirm('Reset dashboard to defaults?')) { S.data.widgets = [{ uid: uid(), type: 'citytime', size: 'm', cfg: {} }, { uid: uid(), type: 'calendar', size: 'l', cfg: {} }]; save(); } } }, 'Reset dashboard');
    v.replaceChildren(h('div', { class: 'set' },
      h('section', {}, h('h3', {}, 'Accent'), sw),
      h('section', {}, h('h3', {}, 'Display'),
        h('label', { class: 'dim' }, 'Motion', sel([['full', 'Full'], ['reduced', 'Reduced']], s.motion, x => set('motion', x))),
        h('label', { class: 'dim' }, 'Starfield', sel([[1, 'On'], [0, 'Off']], s.stars ? 1 : 0, x => set('stars', x === '1'))),
        h('label', { class: 'dim' }, 'Density', sel([['comfortable', 'Comfortable'], ['compact', 'Compact']], s.density, x => set('density', x)))),
      h('section', {}, h('h3', {}, 'Time and place'),
        h('label', { class: 'dim' }, 'Clock format', sel([[1, '24 hour'], [0, '12 hour']], s.h24 ? 1 : 0, x => set('h24', x === '1'))),
        h('label', { class: 'dim' }, 'Home city', sel(Object.keys(CITIES).map(c => [c, c]), s.city, x => set('city', x)))),
      h('section', {}, h('h3', {}, 'Account ' + (S.user?.name || '')), reset)));
    pop(v.firstChild.children);
  },
});
